require("dotenv").config();
const { REST, Routes } = require("discord.js");

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
    try {
        console.log("Limpando comandos globais...");
        await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: [] });
        console.log("Comandos globais removidos.");

        if (process.env.GUILD_ID) {
            console.log("Limpando comandos do servidor...");
            await rest.put(
                Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
                { body: [] }
            );
            console.log("Comandos do servidor removidos.");
        }

        console.log("Limpeza concluída.");
    } catch (error) {
        console.error("Erro:", error.message);
    }
})();
