const {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ContainerBuilder,
    MessageFlags,
    SectionBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    TextDisplayBuilder,
} = require("discord.js");

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function separator() {
    return new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true);
}

function text(content) {
    return new TextDisplayBuilder().setContent(content);
}

// ---------------------------------------------------------------------------
// Card principal — título + ⚙️ na mesma linha (Section), select abaixo
// ---------------------------------------------------------------------------
function panelComponents() {
    // Botão de engrenagem — acessório da Section (fica à direita do título)
    const gearButton = new ButtonBuilder()
        .setCustomId("hypesquad_config_token")
        .setEmoji("⚙️")
        .setStyle(ButtonStyle.Secondary);

    // Section: título + descrição à esquerda, ⚙️ à direita
    const headerSection = new SectionBuilder()
        .addTextDisplayComponents(text("**HypeSquad Changer**"))
        .addTextDisplayComponents(text("Gerencie sua insígnia do **HypeSquad** de forma rápida e fácil."))
        .setButtonAccessory(gearButton);

    // Select menu com as 4 opções
    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId("hypesquad_select")
        .setPlaceholder("Escolha uma casa do HypeSquad...")
        .addOptions(
            new StringSelectMenuOptionBuilder()
                .setLabel("Bravery")
                .setDescription("Trocar para HypeSquad Bravery")
                .setValue("bravery")
                .setEmoji({ id: "1526048175260176464" }),
            new StringSelectMenuOptionBuilder()
                .setLabel("Brilliance")
                .setDescription("Trocar para HypeSquad Brilliance")
                .setValue("brilliance")
                .setEmoji({ id: "1526048295984693359" }),
            new StringSelectMenuOptionBuilder()
                .setLabel("Balance")
                .setDescription("Trocar para HypeSquad Balance")
                .setValue("balance")
                .setEmoji({ id: "1526048253760508099" }),
            new StringSelectMenuOptionBuilder()
                .setLabel("Remover Insígnia")
                .setDescription("Remover sua insígnia do HypeSquad")
                .setValue("remove")
                .setEmoji("🗑️"),
        );

    const selectRow = new ActionRowBuilder().addComponents(selectMenu);

    const container = new ContainerBuilder()
        .addSectionComponents(headerSection)
        .addSeparatorComponents(separator())
        .addActionRowComponents(selectRow);

    return [container];
}

// ---------------------------------------------------------------------------
// Mensagem de status (sucesso / erro / aviso / info)
// ---------------------------------------------------------------------------
function statusComponents({ type, title, description, details }) {
    const colors = {
        success: 0x2ECC71,
        error:   0xE74C3C,
        warning: 0xF1C40F,
        info:    0x5865F2,
    };

    const icons = {
        success: "✅",
        error:   "❌",
        warning: "⚠️",
        info:    "ℹ️",
    };

    const container = new ContainerBuilder()
        .addTextDisplayComponents(text(`# ${icons[type] || icons.info} ${title}`))
        .addTextDisplayComponents(text(description));

    if (details) {
        container
            .addSeparatorComponents(separator())
            .addTextDisplayComponents(text(details));
    }

    return [container];
}

// ---------------------------------------------------------------------------
// Helpers de label
// ---------------------------------------------------------------------------
const houseNames = {
    bravery:    "Bravery",
    brilliance: "Brilliance",
    balance:    "Balance",
    remove:     "Remover Insígnia",
};

function houseLabel(house) {
    return houseNames[house] || house;
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------
module.exports = {
    houseLabel,
    panelComponents,
    statusComponents,
    v2Flags:        MessageFlags.IsComponentsV2,
    v2PrivateFlags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
};
